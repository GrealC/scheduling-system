package com.example.scheduling_system.Dao;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.scheduling_system.Entity.store;
import com.fasterxml.jackson.databind.ser.Serializers;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface storeMapper extends BaseMapper<store> {


}
